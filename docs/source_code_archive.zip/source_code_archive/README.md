# InterviewEcho 源码归档

**项目名称**: InterviewEcho — AI 模拟面试系统  
**版本**: v2.0  
**归档日期**: 2026 年 7 月  

---

## 一、项目简介

InterviewEcho 是一个面向计算机技术岗位（Java 后端、Web 前端、Python 算法）的 AI 模拟面试训练系统。系统通过 AI 大语言模型驱动完整面试流程，支持语音/文字双模式交互、简历解析、GitHub 项目分析、在线代码判题以及多维度评估报告生成。

## 二、目录结构

```
source_code_archive/
├── README.md                    # 本文件
├── docker-compose.yml           # Docker 容器编排
├── .env.example                 # 环境变量模板
│
├── backend/                     # 后端源码 (FastAPI + Python)
│   ├── main.py                  # 应用入口
│   ├── requirements.txt         # Python 依赖
│   ├── alembic.ini              # 数据库迁移配置
│   ├── app/                     # 主应用包
│   │   ├── api/                 # API 路由 & 认证
│   │   ├── core/                # 核心引擎
│   │   ├── services/            # 业务服务
│   │   ├── db/                  # 数据持久化
│   │   └── cli/                 # CLI 工具
│   ├── core/                    # LLM 服务 & 提示词
│   ├── services/                # 外部服务适配
│   ├── evaluation/              # 表达评分模块
│   ├── rag/                     # RAG 向量检索
│   ├── alembic/                 # 数据库迁移脚本
│   └── tests/                   # 完整测试套件 (21 个文件)
│
├── frontend/                    # 前端源码 (Vue 3)
│   ├── package.json             # Node.js 依赖
│   ├── vite.config.js           # Vite 构建配置
│   └── src/                     # Vue 源码
│
├── knowledge-base/              # 知识库 (题库 & 提示词)
│   ├── system_prompts.md        # LLM Prompt 模板
│   ├── java-backend/            # Java 题库
│   ├── web-frontend/            # 前端题库
│   └── python-algorithm/        # Python 题库
│
└── docs/                        # 项目文档
```

## 三、环境要求

- Python 3.12+
- Node.js 20+
- MySQL 8.0 (生产; 测试用 SQLite)

## 四、快速启动

### 后端
```bash
cd backend
pip install -r requirements.txt
alembic upgrade head
python -m app.cli.seed_code_problems
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

### 前端
```bash
cd frontend
npm install
npm run dev
```

### Docker
```bash
cp .env.example .env
# 编辑 .env 填入 LLM_API_KEY
docker-compose up -d
```

## 五、运行测试

```bash
cd backend
# 全部单元测试 (无需外部服务)
pytest tests/ -v --ignore=tests/test_repo_analyzer.py --ignore=tests/test_audio_analysis.py
# 预期: 约 290 个测试全部通过
```

## 六、测试文件清单 (共 293+ 用例)

| 测试文件 | 测试目标 | 依赖 |
|---------|---------|------|
| test_interrupt_policy.py | 打断策略判定 | 无 |
| test_judge0_service.py | Judge0 判题服务 | 无 |
| test_role_criteria.py | 岗位评估标准 | 无 |
| test_prompts.py | Prompt 模板管理 | system_prompts.md |
| test_expression_evaluator_unit.py | 表达评分 | monkeypatch LLM |
| test_schemas.py | Pydantic 数据校验 | 无 |
| test_interview_catalog.py | 题库加载与筛选 | knowledge-base/ |
| test_auth_deps.py | 认证 Token 解析 | SQLite |
| test_resume_parser.py | 简历解析与 Persona | monkeypatch LLM |
| test_models.py | ORM 模型 CRUD | SQLite |
| test_code_routes.py | 代码判题 API | SQLite + mock Judge0 |
| test_interview_runtime_unit.py | 面试状态机引擎 | SQLite + mock LLM |
| test_voice_message_flow.py | 语音消息全链路 | SQLite + mock |
| test_e2e.py | 端到端黄金路径 | SQLite + LLM(部分) |
| test_evaluation_reporting.py | 评估报告生成 | mock LLM |
| test_migrations.py | 数据库迁移 | SQLite |
| test_seed.py | 种子数据幂等性 | SQLite |
| test_knowledge_base.py | 题库质量验证 | knowledge-base/ |

## 七、技术栈

- **后端**: Python 3.12 + FastAPI + SQLAlchemy 2.0 + Alembic
- **前端**: Vue 3.4 + Vite 5 + Element Plus + Pinia + ECharts
- **AI**: OpenAI 兼容 API + Whisper 语音识别
- **判题**: Judge0 (Docker 自建)
- **测试**: pytest + FastAPI TestClient + monkeypatch
